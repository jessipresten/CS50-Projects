from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    pass

class Transaction(models.Model):
    amount=models.FloatField()
    category=models.CharField(max_length=64)
    date=models.DateTimeField(auto_now_add=True)
    type=models.CharField(max_length= 64)
    user=models.ForeignKey(User,on_delete=models.CASCADE, related_name="user_transaction",blank=True,null=True)


