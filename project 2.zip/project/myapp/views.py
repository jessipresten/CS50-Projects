from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from datetime import datetime
from django.shortcuts import get_object_or_404
from .models import User,Transaction
from django.http import JsonResponse

def index(request):
    transactions = Transaction.objects.all()
    return render(request, "myapp/index.html",{
      "transactions": transactions
 })


@login_required
def add_transaction(request):
    if request.method=="GET":
        return render(request,"myapp/add_transaction.html")
    else:
        amount = request.POST["amount"]
        type = request.POST["type"]
        category=request.POST["category"]
        user=request.user
        new_row = Transaction(amount=amount, type=type, category= category, user=user, date=datetime.now())
        new_row.save()
        return HttpResponseRedirect(reverse("index"))

@login_required
def delete_transaction(request, id):
    current_user = request.user
    row_to_delete = get_object_or_404(Transaction, pk=id, user=current_user)
    row_to_delete.delete()
    return HttpResponseRedirect(reverse("index"))

def total_balance(request):
    current_user= request.user
    transactions= Transaction.objects.filter(user=current_user)
    income= 0
    expense = 0
    for row in transactions:
        if row.type == "income":
            income+= row.amount
        if row.type == "expense":
            expense+= row.amount
    total= income - expense
    return JsonResponse({"message": total})






@login_required
def edit_transaction(request, id):
    current_user = request.user
    current_user = request.user
    db_user = User.objects.get(username__iexact=current_user.username)  # Case-insensitive match


    try:
        row_to_edit = get_object_or_404(Transaction, pk=id, user=db_user)
        print("Transaction found!")

    except:
        print("Transaction NOT found!")
        return HttpResponse("Transaction not found", status=404)


    if request.method == "POST":
        amount = request.POST.get("amount")
        transaction_type = request.POST.get("type")  # Renamed to avoid conflict
        category = request.POST.get("category")

        if not amount or not transaction_type or not category:
            return HttpResponse("Missing required fields", status=400)

        try:
            row_to_edit.amount = float(amount)  # Ensure numeric value
        except ValueError:
            return HttpResponse("Invalid amount format", status=400)

        row_to_edit.type = transaction_type
        row_to_edit.category = category
        row_to_edit.save()

        return HttpResponseRedirect(reverse("index"))

    return render(request, "myapp/edit_transaction.html", {"transaction": row_to_edit})



def login_view(request):
    if request.method == "POST":

        # Attempt to sign user in
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        # Check if authentication successful
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "myapp/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "myapp/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("login"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        # Ensure password matches confirmation
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "myapp/register.html", {
                "message": "Passwords must match."
            })

        # Attempt to create new user
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "myapp/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "myapp/register.html")
