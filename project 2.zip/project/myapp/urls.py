from django.urls import path

from . import views

urlpatterns = [
    path("index", views.index, name="index"),
    path("", views.login_view, name="login"),
    path("logout", views.logout_view, name="logout"),
    path("register", views.register, name="register"),
    path("add_transaction", views.add_transaction, name="add_transaction"),
    path("delete_transaction/<int:id>/", views.delete_transaction, name="delete_transaction"),
    path("edit_transaction/<int:id>/", views.edit_transaction, name="edit_transaction"),
    path("total_balance", views.total_balance, name ="total_balance")
]
